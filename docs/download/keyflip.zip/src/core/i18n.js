// Interface strings (Arabic / English). The extension UI language is chosen in
// settings, independently from the browser language.
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  root.KeyFlip = root.KeyFlip || {};
  root.KeyFlip.i18n = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  const STRINGS = {
    en: {
      appName: 'KeyFlip',
      tagline: 'Typed in the wrong layout? Flip it — don’t retype it.',
      taglineShort: 'Flip it, don’t retype it',
      langAuto: 'Auto',
      themeAuto: 'Auto',
      themeLight: 'Light',
      themeDark: 'Dark',
      on: 'On',
      off: 'Off',
      save: 'Save',
      cancel: 'Cancel',
      apply: 'Apply',
      close: 'Close',
      copy: 'Copy',
      copied: 'Copied!',
      reset: 'Reset',
      swap: 'Swap',
      next: 'Next',
      back: 'Back',
      skip: 'Skip',
      done: 'Done',
      settings: 'Settings',
      recommended: 'Recommended',
      detected: 'Detected',
      forYourOs: 'For {os}',

      // Popup
      popupEnabled: 'KeyFlip is on',
      popupDisabled: 'KeyFlip is paused',
      popupSiteOn: 'Active on {site}',
      popupSiteOff: 'Paused on {site}',
      popupSiteToggle: 'Use on this site',
      popupNoSite: 'Browsers don’t let extensions work on this page',
      accessTitle: 'KeyFlip can’t reach your websites',
      accessBody: 'Site access was limited in the browser’s extension settings, so the shortcut and right-click can’t fix text on websites. Your text still never leaves your device.',
      accessButton: 'Allow on all websites',
      blockedTitle: 'KeyFlip can’t edit this page',
      blockedBody: 'Browsers protect their own pages and the extension store. Your text is flipped below — copy it and paste it back.',
      popupKeyboards: 'Your keyboards',
      popupHowTo: 'Select the text, then press',
      popupOrMenu: 'or right-click → Fix keyboard layout',
      popupQuick: 'Quick flip',
      popupQuickHint: 'Paste text typed in the wrong layout…',
      popupQuickEmpty: 'The flipped text appears here',
      popupStatsLink: 'Time saved',
      popupPrivacy: 'Works offline · your text never leaves this device',

      // Stats
      statFlips: 'Texts fixed',
      statChars: 'Characters not retyped',
      statMinutes: 'Minutes saved',
      statLast14: 'Minutes saved · last 14 days',
      statsHow: 'Estimated from your typing speed: the time you would have spent deleting, switching the keyboard and typing the text again.',
      chartTip: '{minutes} min saved · {flips} fixes',
      statEmpty: 'Your first flip will show up here.',
      shareTitle: 'Share your progress',
      shareText: 'KeyFlip has saved me {minutes} minutes so far: it fixes text typed in the wrong keyboard language in one shortcut, no retyping. ⌨️⇄',
      shareCopy: 'Copy text',
      shareImage: 'Download image',
      shareX: 'Post on X',
      shareWhatsApp: 'WhatsApp',
      shareLinkedIn: 'LinkedIn',
      shareCardHeadline: 'minutes saved',
      shareCardFlips: 'texts fixed',
      shareCardChars: 'characters not retyped',
      resetStats: 'Reset statistics',
      resetStatsConfirm: 'Reset all statistics? This cannot be undone.',

      // Options
      navGeneral: 'General',
      navKeyboards: 'Keyboards',
      navActivation: 'Activation',
      navSmart: 'Smart handling',
      navStats: 'Your stats',
      navAbout: 'Privacy & about',
      generalTitle: 'General',
      generalDesc: 'Turn KeyFlip on or off and choose how it looks.',
      enableLabel: 'Enable KeyFlip',
      enableDesc: 'Pause it anytime without uninstalling.',
      uiLanguageLabel: 'Extension language',
      uiLanguageDesc: 'Language of KeyFlip’s own menus and buttons.',
      themeLabel: 'Appearance',
      themeDesc: 'Follow the system or force light or dark.',
      keyboardsTitle: 'Your keyboards',
      keyboardsDesc: 'Pick the two layouts you switch between. A language can have several layouts, so choose the exact one you type with.',
      layoutALabel: 'First layout',
      layoutBLabel: 'Second layout',
      osDetected: 'We detected {os}',
      macNote: 'Mac Arabic is laid out very differently from Windows Arabic (101). If you use “Arabic – PC” on a Mac, choose Arabic (101).',
      previewTitle: 'Key map: check that it matches your keyboard',
      previewDesc: 'Each key shows what it types in your first layout (top) and in your second layout (bottom, in color). If the colored letters don’t match the ones printed on your keyboard, choose a different second layout above.',
      previewShift: 'Show Shift layer',
      detectTitle: 'Not sure which layout you have? Detect it',
      detectDesc: '1. Switch your computer to your other keyboard language (for example Arabic).  2. Click the box and press any letter key.',
      detectPlaceholder: 'Type here using your other keyboard…',
      detectResult: 'Detected: {name}',
      detectIsFirst: 'That is your first layout ({name}). Switch your computer to the other keyboard language, then press a key again.',
      detectAlready: '✓ {name} — already selected',
      detectUse: 'Use this layout',
      detectNeedMore: 'Press one or two more keys…',
      detectNoMatch: 'This layout isn’t in the list yet. Pick the closest one above.',
      activationTitle: 'Activation',
      activationDesc: 'Choose how you trigger a flip.',
      shortcutLabel: 'Keyboard shortcut',
      shortcutDesc: 'Ctrl+A selects everything, and Q sits right above A, so fixing is one short move.',
      shortcutDescMac: 'On a Mac, select with ⌘ Command + A, then press ⌃ Control + Q. KeyFlip uses Control, not Command, because ⌘ Command + Q would quit the browser.',
      shortcutRecord: 'Click, then press your shortcut',
      shortcutRecording: 'Press the keys now…',
      shortcutReserved: 'The browser or system already uses this combination. Pick another one.',
      shortcutInvalid: 'Use at least Ctrl or Alt with a key.',
      shortcutInvalidMac: 'Use at least ⌃ Control, ⌥ Option or ⌘ Command with a key.',
      shortcutReset: 'Reset to {default}',
      fabLabel: 'Floating button',
      fabDesc: 'Shows a small flip button when you select text in a text box.',
      fabReadOnlyLabel: 'Floating button on page text too',
      fabReadOnlyDesc: 'Decode gibberish someone else typed, right on the page.',
      menuLabel: 'Right-click menu',
      menuDesc: 'Right-click selected text (or inside a text box) and choose “Fix keyboard layout”.',
      toastLabel: 'Confirmation bubble',
      toastDesc: 'A short message after each flip.',
      noSelLabel: 'When nothing is selected',
      noSelField: 'Flip the whole field',
      noSelWord: 'Flip the last word',
      noSelNone: 'Do nothing',
      sitesLabel: 'Paused sites',
      sitesDesc: 'KeyFlip stays quiet on these sites. Add one from the toolbar popup.',
      sitesEmpty: 'No paused sites.',
      remove: 'Remove',
      smartTitle: 'Smart handling',
      smartDesc: 'Some Arabic keys type two letters. On Windows, the B key types “لا” — the same as G then H. KeyFlip can’t always know which one you pressed.',
      ambSmart: 'Smart (recommended)',
      ambSmartDesc: 'Decides using a word list and asks only when unsure.',
      ambAsk: 'Always ask me',
      ambAskDesc: 'Shows a quick chooser every time.',
      ambSingle: 'Always one key',
      ambSingleDesc: '“لا” becomes B.',
      ambDouble: 'Always two keys',
      ambDoubleDesc: '“لا” becomes GH.',
      tryTitle: 'Try it here',
      tryDesc: 'Select the text and press {shortcut}, or use the floating button.',
      tryPlaceholder: 'Type something with the wrong layout…',
      wpmLabel: 'Your typing speed',
      wpmDesc: 'Used to estimate time saved: {wpm} words per minute.',
      aboutTitle: 'Privacy & about',
      privacyHeadline: 'Everything stays on your device',
      privacyBody: 'KeyFlip works fully offline. It reads the text you select only to convert it, right on your device, and never sends, logs or shares it. Your settings and simple counters (number of flips, characters, minutes saved) are stored locally in your browser.',
      browsersLabel: 'Works on',
      browsersBody: 'Google Chrome, Microsoft Edge, Brave, Opera, Vivaldi and other Chromium browsers (Manifest V3).',
      limitsLabel: 'Good to know',
      limitsBody: 'Browsers don’t let extensions run on internal browser pages or the extension store, and some online document editors draw text on a canvas instead of a text box. In those places, use the Quick flip box in the toolbar popup. On Opera, turn on “Allow access to search page results” in the extension settings to use KeyFlip on search pages.',
      versionLabel: 'Version',
      replayOnboarding: 'Replay the welcome tour',
      resetSettings: 'Reset all settings',
      resetSettingsConfirm: 'Reset all settings to their defaults?',
      saved: 'Saved',

      // Onboarding
      obLangTitle: 'Choose your language',
      obLangSub: 'You can change it later in Settings.',
      obIntroTitle: 'Typed in the wrong keyboard?',
      obIntroBody: 'Everyone has typed a full sentence before noticing the keyboard was in the other language. KeyFlip fixes it in place — no deleting, no retyping.',
      obStep1: 'Select the text',
      obStep2: 'Press {shortcut}',
      obStep2Menu: 'or right-click and choose “Fix keyboard layout”',
      obStep3: 'Done — it’s flipped',
      macHint: 'Mac: use ⌃ Control (not ⌘ Command) — ⌘ Command + Q would quit the browser.',
      obPrivacyTitle: 'Your text stays on your device',
      obPrivacyBody: 'To flip text, KeyFlip reads only the text you select, on your device. Nothing is sent anywhere — no servers, no analytics.',
      obKbTitle: 'Which keyboards do you use?',
      obKbBody: 'Pick the exact layouts. They decide which letter each key becomes.',
      obTryTitle: 'Give it a try',
      obTryBody: 'Press {select} to select everything, then {shortcut} to flip it.',
      obTrySuccess: 'Perfect! That’s all there is to it.',
      obTryWaiting: 'Waiting for your first flip…',
      obDoneTitle: 'You’re all set',
      obDoneBody: 'Pin KeyFlip to your toolbar to reach your stats and settings quickly.',
      obPinHint: 'Click the puzzle icon in the toolbar, then the pin next to KeyFlip.',
      obReloadHint: 'Tabs that were already open start working after a refresh.',
      obOpenSettings: 'Open settings',
      obFinish: 'Start using KeyFlip',

      // In-page UI
      fabFlip: 'Flip',
      fabTitle: 'Flip keyboard layout ({shortcut})',
      toastFlipped: { one: 'Flipped {n} character', other: 'Flipped {n} characters' },
      toastUndo: '{undo} to undo',
      toastNothing: 'Nothing to flip here',
      toastSelectFirst: 'Select some text first',
      dlgTitle: 'Which one did you mean?',
      dlgSubtitle: 'Some keys type two letters, so this text can be read more than one way.',
      dlgPreview: 'Preview',
      dlgApply: 'Apply',
      dlgHint: 'Enter to apply · Esc to cancel',
      cardTitle: 'Flipped text',
      menuFlip: 'Fix keyboard layout ({shortcut})',
    },

    ar: {
      appName: 'KeyFlip',
      tagline: 'كتبت والكيبورد على اللغة الغلط؟ اقلب النص بدل ما تعيد كتابته.',
      taglineShort: 'اقلبه بدل ما تعيد كتابته',
      langAuto: 'تلقائي',
      themeAuto: 'تلقائي',
      themeLight: 'فاتح',
      themeDark: 'داكن',
      on: 'مُفعّل',
      off: 'متوقف',
      save: 'حفظ',
      cancel: 'إلغاء',
      apply: 'تطبيق',
      close: 'إغلاق',
      copy: 'نسخ',
      copied: 'تم النسخ!',
      reset: 'إعادة ضبط',
      swap: 'تبديل',
      next: 'التالي',
      back: 'السابق',
      skip: 'تخطي',
      done: 'تم',
      settings: 'الإعدادات',
      recommended: 'موصى به',
      detected: 'تم اكتشافه',
      forYourOs: 'لنظام {os}',

      popupEnabled: 'KeyFlip يعمل',
      popupDisabled: 'KeyFlip متوقف مؤقتاً',
      popupSiteOn: 'يعمل على {site}',
      popupSiteOff: 'متوقف على {site}',
      popupSiteToggle: 'التفعيل على هذا الموقع',
      popupNoSite: 'المتصفح لا يسمح للإضافات بالعمل في هذه الصفحة',
      accessTitle: 'KeyFlip لا يستطيع الوصول إلى المواقع',
      accessBody: 'تم تقييد وصول الإضافة إلى المواقع من إعدادات المتصفح، لذلك لا يعمل الاختصار ولا الزر الأيمن على المواقع. نصك يبقى على جهازك دائماً.',
      accessButton: 'اسمح على كل المواقع',
      blockedTitle: 'لا يستطيع KeyFlip تعديل هذه الصفحة',
      blockedBody: 'المتصفح يحمي صفحاته الخاصة ومتجر الإضافات. هذا نصك بعد القلب — انسخه والصقه مكانه.',
      popupKeyboards: 'لوحات المفاتيح',
      popupHowTo: 'ظلّل النص ثم اضغط',
      popupOrMenu: 'أو زر الماوس الأيمن ← صحّح لغة الكيبورد',
      popupQuick: 'قلب سريع',
      popupQuickHint: 'الصق نصاً مكتوباً بلغة الكيبورد الخطأ…',
      popupQuickEmpty: 'سيظهر النص المصحَّح هنا',
      popupStatsLink: 'الوقت الموفّر',
      popupPrivacy: 'يعمل بدون إنترنت · نصك لا يغادر جهازك',

      statFlips: 'نصوص تم تصحيحها',
      statChars: 'حروف لم تُعِد كتابتها',
      statMinutes: 'دقائق تم توفيرها',
      statLast14: 'الدقائق الموفّرة · آخر 14 يوماً',
      statsHow: 'تقدير حسب سرعة كتابتك: الوقت الذي كنت ستقضيه في مسح النص وتبديل الكيبورد وإعادة الكتابة.',
      chartTip: 'وفّرت {minutes} دقيقة · {flips} تصحيحات',
      statEmpty: 'أول عملية قلب ستظهر هنا.',
      shareTitle: 'شارك إنجازك',
      shareText: 'وفّر لي KeyFlip حتى الآن {minutes} دقيقة: يصحّح النص المكتوب بلغة الكيبورد الخطأ باختصار واحد، بدون إعادة كتابة. ⌨️⇄',
      shareCopy: 'نسخ النص',
      shareImage: 'تنزيل صورة',
      shareX: 'انشر على X',
      shareWhatsApp: 'واتساب',
      shareLinkedIn: 'لينكدإن',
      shareCardHeadline: 'دقيقة تم توفيرها',
      shareCardFlips: 'نص تم تصحيحه',
      shareCardChars: 'حرف لم تُعَد كتابته',
      resetStats: 'تصفير الإحصائيات',
      resetStatsConfirm: 'هل تريد تصفير كل الإحصائيات؟ لا يمكن التراجع عن ذلك.',

      navGeneral: 'عام',
      navKeyboards: 'لوحات المفاتيح',
      navActivation: 'طرق التفعيل',
      navSmart: 'المعالجة الذكية',
      navStats: 'إحصائياتك',
      navAbout: 'الخصوصية وحول',
      generalTitle: 'عام',
      generalDesc: 'شغّل KeyFlip أو أوقفه واختر شكله.',
      enableLabel: 'تفعيل KeyFlip',
      enableDesc: 'أوقفه مؤقتاً متى شئت بدون حذفه.',
      uiLanguageLabel: 'لغة الإضافة',
      uiLanguageDesc: 'لغة قوائم وأزرار KeyFlip نفسها.',
      themeLabel: 'المظهر',
      themeDesc: 'اتبع النظام أو اختر فاتحاً أو داكناً.',
      keyboardsTitle: 'لوحات المفاتيح',
      keyboardsDesc: 'اختر التخطيطين اللذين تتنقل بينهما. اللغة الواحدة قد يكون لها أكثر من تخطيط، فاختر التخطيط الذي تكتب به فعلاً.',
      layoutALabel: 'التخطيط الأول',
      layoutBLabel: 'التخطيط الثاني',
      osDetected: 'اكتشفنا أنك تستخدم {os}',
      macNote: 'العربية على ماك مختلفة كثيراً عن العربية (101) في ويندوز. إذا كنت تستخدم «Arabic – PC» على ماك فاختر العربية (101).',
      previewTitle: 'خريطة المفاتيح: تأكد أنها تطابق الكيبورد عندك',
      previewDesc: 'كل مفتاح يعرض ما يكتبه في تخطيطك الأول (أعلى) وفي تخطيطك الثاني (أسفل، بلون مميز). إذا لم تطابق الحروف الملوّنة الحروف المطبوعة على الكيبورد عندك، اختر تخطيطاً ثانياً آخر من الأعلى.',
      previewShift: 'إظهار طبقة Shift',
      detectTitle: 'لست متأكداً أي تخطيط عندك؟ اكتشفه تلقائياً',
      detectDesc: '1. حوّل لغة الكيبورد في جهازك إلى اللغة الثانية (العربية مثلاً).  2. اضغط داخل المربع واضغط أي حرف.',
      detectPlaceholder: 'اكتب هنا بالكيبورد الآخر…',
      detectResult: 'تم الاكتشاف: {name}',
      detectIsFirst: 'هذا تخطيطك الأول ({name}). حوّل لغة الكيبورد في جهازك إلى اللغة الثانية ثم اضغط حرفاً مرة أخرى.',
      detectAlready: '✓ {name} — مختار مسبقاً',
      detectUse: 'استخدم هذا التخطيط',
      detectNeedMore: 'اضغط حرفاً أو حرفين بعد…',
      detectNoMatch: 'هذا التخطيط غير موجود في القائمة بعد. اختر الأقرب له من الأعلى.',
      activationTitle: 'طرق التفعيل',
      activationDesc: 'اختر كيف تشغّل عملية القلب.',
      shortcutLabel: 'اختصار لوحة المفاتيح',
      shortcutDesc: 'تضغط Ctrl+A لتحديد النص، وحرف Q فوق A مباشرة، فالتصحيح حركة إصبع واحدة.',
      shortcutDescMac: 'على الماك: حدّد النص بـ \u2066⌘ Command + A\u2069، ثم اضغط \u2066⌃ Control + Q\u2069. يستخدم KeyFlip زر \u2066Control\u2069 وليس \u2066Command\u2069 لأن \u2066⌘ Command + Q\u2069 يغلق المتصفح.',
      shortcutRecord: 'اضغط هنا ثم اضغط الاختصار',
      shortcutRecording: 'اضغط المفاتيح الآن…',
      shortcutReserved: 'هذا الاختصار يستخدمه المتصفح أو النظام. اختر غيره.',
      shortcutInvalid: 'استخدم Ctrl أو Alt مع مفتاح.',
      shortcutInvalidMac: 'استخدم \u2066⌃ Control\u2069 أو \u2066⌥ Option\u2069 أو \u2066⌘ Command\u2069 مع مفتاح.',
      shortcutReset: 'إرجاع {default}',
      fabLabel: 'الزر العائم',
      fabDesc: 'يظهر زر قلب صغير عندما تظلّل نصاً داخل مربع كتابة.',
      fabReadOnlyLabel: 'الزر العائم على نصوص الصفحة أيضاً',
      fabReadOnlyDesc: 'افهم الطلاسم التي كتبها غيرك مباشرة على الصفحة.',
      menuLabel: 'قائمة الزر الأيمن',
      menuDesc: 'اضغط بالزر الأيمن على النص المظلّل (أو داخل مربع الكتابة) واختر «صحّح لغة الكيبورد».',
      toastLabel: 'فقاعة التأكيد',
      toastDesc: 'رسالة قصيرة بعد كل عملية قلب.',
      noSelLabel: 'عندما لا يوجد نص مظلّل',
      noSelField: 'اقلب الحقل كاملاً',
      noSelWord: 'اقلب آخر كلمة',
      noSelNone: 'لا تفعل شيئاً',
      sitesLabel: 'مواقع متوقف عليها',
      sitesDesc: 'لا يعمل KeyFlip على هذه المواقع. أضف موقعاً من النافذة المنبثقة في شريط الأدوات.',
      sitesEmpty: 'لا توجد مواقع متوقفة.',
      remove: 'إزالة',
      smartTitle: 'المعالجة الذكية',
      smartDesc: 'بعض مفاتيح الكيبورد العربي تكتب حرفين. في ويندوز، مفتاح B يكتب «لا» — وهي نفسها G ثم H. لذلك لا يستطيع KeyFlip دائماً معرفة ما الذي ضغطته.',
      ambSmart: 'ذكي (موصى به)',
      ambSmartDesc: 'يقرر باستخدام قاموس كلمات ويسألك فقط عند الشك.',
      ambAsk: 'اسألني دائماً',
      ambAskDesc: 'يعرض نافذة اختيار سريعة في كل مرة.',
      ambSingle: 'مفتاح واحد دائماً',
      ambSingleDesc: '«لا» تصبح B.',
      ambDouble: 'مفتاحان دائماً',
      ambDoubleDesc: '«لا» تصبح GH.',
      tryTitle: 'جرّبه هنا',
      tryDesc: 'ظلّل النص واضغط {shortcut}، أو استخدم الزر العائم.',
      tryPlaceholder: 'اكتب شيئاً بلغة الكيبورد الخطأ…',
      wpmLabel: 'سرعة كتابتك',
      wpmDesc: 'تُستخدم لتقدير الوقت الموفَّر: {wpm} كلمة في الدقيقة.',
      aboutTitle: 'الخصوصية وحول',
      privacyHeadline: 'كل شيء يبقى على جهازك',
      privacyBody: 'يعمل KeyFlip بالكامل بدون إنترنت. يقرأ النص الذي تظلّله فقط لتحويله على جهازك، ولا يرسله ولا يسجّله ولا يشاركه أبداً. تُحفظ إعداداتك وعدّادات بسيطة (عدد مرات القلب والحروف والدقائق الموفّرة) محلياً في متصفحك.',
      browsersLabel: 'يعمل على',
      browsersBody: 'جوجل كروم، مايكروسوفت إيدج، بريف، أوبرا، فيفالدي وباقي متصفحات Chromium (Manifest V3).',
      limitsLabel: 'معلومة مفيدة',
      limitsBody: 'المتصفحات لا تسمح للإضافات بالعمل على صفحات المتصفح الداخلية ومتجر الإضافات، وبعض محررات المستندات على الإنترنت ترسم النص بدل استخدام مربع كتابة. في هذه الأماكن استخدم «قلب سريع» من نافذة الإضافة. على متصفح أوبرا فعّل خيار «Allow access to search page results» من إعدادات الإضافة لاستخدامها في صفحات نتائج البحث.',
      versionLabel: 'الإصدار',
      replayOnboarding: 'إعادة جولة الترحيب',
      resetSettings: 'إعادة ضبط كل الإعدادات',
      resetSettingsConfirm: 'هل تريد إرجاع كل الإعدادات إلى الوضع الافتراضي؟',
      saved: 'تم الحفظ',

      obLangTitle: 'اختر لغتك',
      obLangSub: 'يمكنك تغييرها لاحقاً من الإعدادات.',
      obIntroTitle: 'كتبت والكيبورد على اللغة الغلط؟',
      obIntroBody: 'كلنا كتبنا جملة كاملة قبل أن ننتبه أن الكيبورد على اللغة الأخرى. KeyFlip يصلحها مكانها — بدون مسح وبدون إعادة كتابة.',
      obStep1: 'ظلّل النص',
      obStep2: 'اضغط {shortcut}',
      obStep2Menu: 'أو اضغط بزر الماوس الأيمن واختر «صحّح لغة الكيبورد»',
      obStep3: 'انتهى — انقلب النص',
      macHint: 'على الماك: استخدم \u2066⌃ Control\u2069 (وليس \u2066⌘ Command\u2069) — لأن \u2066⌘ Command + Q\u2069 يغلق المتصفح.',
      obPrivacyTitle: 'نصك يبقى على جهازك',
      obPrivacyBody: 'لقلب النص، يقرأ KeyFlip النص الذي تظلّله فقط وعلى جهازك. لا يُرسل أي شيء إلى أي مكان — لا خوادم ولا تحليلات.',
      obKbTitle: 'ما لوحات المفاتيح التي تستخدمها؟',
      obKbBody: 'اختر التخطيطات بدقة، فهي التي تحدد أي حرف يقابل كل مفتاح.',
      obTryTitle: 'جرّبه الآن',
      obTryBody: 'اضغط {select} لتحديد كل النص، ثم {shortcut} لقلبه.',
      obTrySuccess: 'ممتاز! هذا كل ما في الأمر.',
      obTryWaiting: 'بانتظار أول عملية قلب…',
      obDoneTitle: 'كل شيء جاهز',
      obDoneBody: 'ثبّت KeyFlip في شريط الأدوات لتصل بسرعة إلى إحصائياتك وإعداداتك.',
      obPinHint: 'اضغط أيقونة قطعة البازل في شريط الأدوات، ثم الدبوس بجانب KeyFlip.',
      obReloadHint: 'التبويبات المفتوحة مسبقاً ستعمل بعد تحديثها.',
      obOpenSettings: 'فتح الإعدادات',
      obFinish: 'ابدأ استخدام KeyFlip',

      fabFlip: 'اقلب',
      fabTitle: 'اقلب لغة الكيبورد ({shortcut})',
      toastFlipped: { zero: 'لم يتغير شيء', one: 'تم قلب حرف واحد', two: 'تم قلب حرفين', few: 'تم قلب {n} أحرف', many: 'تم قلب {n} حرفاً', other: 'تم قلب {n} حرف' },
      toastUndo: '{undo} للتراجع',
      toastNothing: 'لا يوجد ما يمكن قلبه هنا',
      toastSelectFirst: 'ظلّل نصاً أولاً',
      dlgTitle: 'أي كلمة كنت تقصد؟',
      dlgSubtitle: 'بعض المفاتيح تكتب حرفين، لذلك يمكن قراءة هذا النص بأكثر من طريقة.',
      dlgPreview: 'معاينة',
      dlgApply: 'تطبيق',
      dlgHint: 'Enter للتطبيق · Esc للإلغاء',
      cardTitle: 'النص بعد القلب',
      menuFlip: 'صحّح لغة الكيبورد ({shortcut})',
    },
  };

  function resolve(setting, browserLang) {
    if (setting === 'ar' || setting === 'en') return setting;
    let b = browserLang;
    if (!b && typeof chrome !== 'undefined' && chrome.i18n && chrome.i18n.getUILanguage) b = chrome.i18n.getUILanguage();
    if (!b && typeof navigator !== 'undefined') b = navigator.language;
    return /^ar\b/i.test(b || '') ? 'ar' : 'en';
  }

  function numberFormat(lang) {
    return new Intl.NumberFormat(lang === 'ar' ? 'ar-u-nu-latn' : 'en');
  }

  function fmt(lang, n) {
    return numberFormat(lang).format(n);
  }

  function t(lang, key, vars) {
    const table = STRINGS[lang] || STRINGS.en;
    let s = table[key] !== undefined ? table[key] : STRINGS.en[key];
    if (s === undefined) return key;
    if (typeof s === 'object') {
      const n = vars && typeof vars.n === 'number' ? vars.n : 0;
      const cat = new Intl.PluralRules(lang === 'ar' ? 'ar' : 'en').select(n);
      s = s[cat] !== undefined ? s[cat] : s.other;
    }
    if (vars) {
      s = s.replace(/\{(\w+)\}/g, (m, k) => {
        if (vars[k] === undefined) return m;
        if (typeof vars[k] === 'number') return fmt(lang, vars[k]);
        const v = String(vars[k]);
        // Keep Latin runs such as "⌃ Control + Q" or a hostname intact inside Arabic text.
        return lang === 'ar' && /[A-Za-z⌃⌘⌥⇧]/.test(v) ? '\u2068' + v + '\u2069' : v;
      });
    }
    return s;
  }

  function dir(lang) {
    return lang === 'ar' ? 'rtl' : 'ltr';
  }

  // Fills [data-i18n], [data-i18n-placeholder|title|aria-label] inside `root`.
  // `vars` provides values for placeholders such as {shortcut}.
  function apply(rootEl, lang, vars) {
    const doc = rootEl.ownerDocument || rootEl;
    if (doc.documentElement && rootEl === doc) {
      doc.documentElement.lang = lang;
      doc.documentElement.dir = dir(lang);
    }
    rootEl.querySelectorAll('[data-i18n]').forEach((el) => {
      el.textContent = t(lang, el.getAttribute('data-i18n'), vars);
    });
    for (const attr of ['placeholder', 'title', 'aria-label']) {
      rootEl.querySelectorAll(`[data-i18n-${attr}]`).forEach((el) => {
        el.setAttribute(attr, t(lang, el.getAttribute(`data-i18n-${attr}`), vars));
      });
    }
  }

  return { STRINGS, resolve, t, fmt, dir, apply };
});
